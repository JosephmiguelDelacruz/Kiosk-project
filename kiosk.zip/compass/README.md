
# Compass

An online Kiosk and customer survey platform installed in school campuses. Still in development.
## Features

- Facilitates Queuing System for daily transactions
- Allows customers to provide feedback of school transactions
- Generates reports for the quality of service given by Registar, Cashiers, etc.

## Run Locally

Clone the project

```bash
  git clone https://markangel@bitbucket.org/cegadev/compass.git
```

Go to the project directory

```bash
  cd compass
```
Install composer dependencies

```bash
  composer install
```

Install npm dependencies

```bash
  npm install
```

Start the server

```bash
  php artisan serve
```

Watch changes on assets
```bash
  npm run dev
```

