import Keyboard from 'simple-keyboard';
import 'simple-keyboard/build/css/index.css';

const keyboard = new Keyboard({
    onChange: input => onChange(input),
    onKeyPress: button => onKeyPress(button),
    layout: {
        default: ["1 2 3", "4 5 6", "7 8 9", "{shift} 0 _", "{bksp}"],
        shift: ["! / #", "$ % ^", "& * (", "{shift} ) +", "{bksp}"]
    },
    theme: "hg-theme-default hg-layout-numeric numeric-theme"
});

function onChange(input){
    document.querySelector(".input").value = input;
    const inputNumber = document.getElementById('inputNumber');
    setInputNumber(inputNumber.value);
    console.log("Input changed", input);
}


function onKeyPress(button) {
    console.log("Button pressed", button);

    /**
     * If you want to handle the shift and caps lock buttons
     */
    if (button === "{shift}" || button === "{lock}") handleShift();
}

function handleShift() {
    let currentLayout = keyboard.options.layoutName;
    let shiftToggle = currentLayout === "default" ? "shift" : "default";

    keyboard.setOptions({
        layoutName: shiftToggle
    });
}

const deviceType = () => {
    const ua = navigator.userAgent;
    if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
        return "tablet";
    }
    else if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
        return "mobile";
    }
    return "desktop";
};

if (deviceType() == 'desktop') {
    document.getElementById("inputNumber").addEventListener("focus", () => {
        document.getElementById("keyboard_wrapper").style.display = "block"
    });
}
