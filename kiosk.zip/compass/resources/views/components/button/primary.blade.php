<x-button.default :noBg="true" {{ $attributes->merge(['class' => 'bg-blue-500 text-white']) }} :custom="true">{{ $slot }}</x-button.default>
