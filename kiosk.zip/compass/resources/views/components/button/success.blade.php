<x-button.default {{ $attributes->merge(['class' => 'bg-green-500 text-white']) }} :custom="true">{{ $slot }}</x-button.default>
