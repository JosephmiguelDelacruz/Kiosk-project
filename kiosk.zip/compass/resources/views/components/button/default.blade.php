@props([
    "route" => null,
    "custom" => false,
    "noBg" => false
])

@if ($route)
    <a href="{{ $route }}" {{ $attributes->merge(['class' => "px-4 py-2 ". ($noBg ? '' : 'bg-white') . " rounded border " . ($custom ? "" : "text-gray-500")]) }}>
        {{ $slot }}
    </a>
@else
    <button {{ $attributes->merge(['class' => "px-4 py-2 ". ($noBg ? '' : 'bg-white') . " rounded border " . ($custom ? "" : "text-gray-500")]) }}>
    {{ $slot }}
    </button>
@endif
