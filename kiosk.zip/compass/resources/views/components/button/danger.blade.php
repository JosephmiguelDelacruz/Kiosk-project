<x-button.default {{ $attributes->merge(['class' => 'bg-red-500 text-white']) }} :custom="true">{{ $slot }}</x-button.default>
