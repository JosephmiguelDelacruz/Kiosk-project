@props([
    "required" => false
])

<div {{ $attributes->merge(['class' => 'mb-2 text-gray-600']) }}>
    <label>{{ $slot }} {!! $required ? "<span class='text-red-500'>*</span>" : "" !!}</label>
</div>
