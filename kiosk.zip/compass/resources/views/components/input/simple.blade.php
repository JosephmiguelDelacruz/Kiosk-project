<input {{ $attributes->merge(['class' => 'px-3 py-2 rounded border w-full']) }} />

@if ($attributes->has("name"))
    @error($attributes->get("name"))
        <x-input.error>{{ $message }}</x-input.error>
    @enderror
@endif
