<div class="text-red-500 my-1 text-sm">{{ $slot }}</div>
