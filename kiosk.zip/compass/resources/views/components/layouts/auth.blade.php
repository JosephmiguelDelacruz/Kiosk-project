<div class="justify-center absolute top-0 left-0 w-screen h-screen bg-blue-50">
{{ $slot }}
</div>
