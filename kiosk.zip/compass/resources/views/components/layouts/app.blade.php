<div class="flex flex-col absolute top-0 left-0 w-full h-full gap-4">
    <div class="flex justify-between px-6 py-4 shadow bg-white">
        <div>
            <img src="/images/compass.png" class="h-10" />
        </div>
        <div class="flex gap-x-6 self-center text-gray-500" wire:ignore>
            <div class="self-center">
                Home
            </div>
            <div class="self-center">
                <a href="{{ route('transactions') }}" class="{{ request()->is("transactions") ? "font-semibold" : "" }}">
                    Transactions
                </a>
            </div>
            <div class="self-center">
                School Directory
            </div>
            <div class="self-center">
                <a href="{{ route('survey') }}" class="{{ request()->is(["survey", "survey/*"]) ? "font-semibold" : "" }}">
                    Survey
                </a>
            </div>
            <div class="self-center">
                Users
            </div>
            <div class="relative" x-data="{dropdownShow: false}">
                <div class="flex gap-x-1 select-none cursor-pointer hover:bg-gray-50 py-2 px-4 rounded-lg" x-on:click="dropdownShow = !dropdownShow" x-bind:class="dropdownShow ? 'bg-gray-50' : ''">
                    <div class="self-center"><x-heroicon-s-user-circle class="w-5 h-5" /></div>
                    <div>{{ auth()->user()->name }}</div>
                    <div class="self-center">
                        <x-heroicon-s-chevron-down class="w-5 h-5" />
                    </div>
                </div>
                <div class="absolute border rounded bg-white w-full top-10 right-0 w-[10em] z-50" x-show="dropdownShow">
                    <a href="#" class="px-3 py-2 flex gap-x-4 text-sm hover:bg-gray-50 block">
                        <x-heroicon-o-user-circle class="w-5 h-5 self-center" /> Profile
                    </a>
                    <a href="logout" class="px-3 py-2 flex gap-x-4 text-sm hover:bg-gray-50 block">
                        <x-heroicon-o-arrow-right-on-rectangle class="w-5 h-5 self-center" /> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="relative flex-grow mx-6 mb-6">
        {{ $slot }}
    </div>
</div>
