@props([
    "title" => null,
    "customTitle" => null,
    "shadow" => true,
    "noContainer" => false
])
<div {{ $attributes->merge(['class' => ($shadow ? 'shadow' : '') . ' rounded bg-white']) }}>
    @if($title)
        <div class="px-3 py-2 border-b">{{ $title }}</div>
    @endif
    @if($customTitle){{ $customTitle }}@endif

    @if ($noContainer)
        {{ $slot }}
    @else
        <div class="px-3 py-2">
            {{ $slot }}
        </div>
    @endif

</div>
