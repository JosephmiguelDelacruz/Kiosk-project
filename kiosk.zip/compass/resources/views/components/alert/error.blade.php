<div class="px-3 py-2 bg-red-50 text-red-500 border rounded border-red-500 mb-3 text-sm">
    {{ $slot }}
</div>
