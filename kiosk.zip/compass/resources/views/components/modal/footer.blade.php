<div {{ $attributes->merge(['class' => 'px-5 py-4 font-semibold text-gray-500 bg-gray-50']) }}>
    {{ $slot }}
</div>
