<table {{ $attributes->merge([
    'class' => 'border w-full',
]) }}>{{ $slot }}</table>
