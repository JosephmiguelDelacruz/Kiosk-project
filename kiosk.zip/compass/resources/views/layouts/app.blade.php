<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    @vite('resources/css/app.css')
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>
        [x-cloak] { display: none }
    </style>
    @livewireStyles

    @stack('styles')

</head>
<body class="bg-gray-50">
{{ $slot }}
@livewireScripts

@stack('scripts')
</body>
</html>
