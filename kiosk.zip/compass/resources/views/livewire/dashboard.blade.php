<x-layouts.app>
    <div class="text-2xl text-gray-600">Welcome {{ auth()->user()->name }}</div>
</x-layouts.app>
