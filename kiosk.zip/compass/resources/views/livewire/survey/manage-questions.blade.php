<x-layouts.app>
    <x-card.simple class="p-5 mb-5" wire:ignore>
        <div class="text-4xl font-semibold text-blue-500">{{ $survey->name }}</div>
    </x-card.simple>
    <x-card.simple title="Manage Questions">
        <div class="mb-5">
            <x-button.primary wire:click="$emit('showCreateQuestion')">
                <x-heroicon-s-plus class="w-5 h-5 inline-block mb-1" />
                Add Question</x-button.primary>
        </div>
        <div>
            @foreach($surveyQuestions as $index => $question)
                <div class="border mb-3 p-5 rounded flex">
                    <div class="flex-grow">
                        <div class="text-xs bg-green-500 inline-block px-3 py-2 rounded-full text-white uppercase mb-3">Question No. {{ $index + 1 }}</div>
                        <div class="">
                            {{ $question->question }}
                        </div>
                    </div>
                    <div class="self-center">
                        <x-button.primary wire:click="editQuestion({{ $question }})">
                            <x-heroicon-s-pencil-square class="h-5 w-5 inline-block mb-1" /> Edit
                        </x-button.primary>
                    </div>
                </div>
            @endforeach
        </div>
    </x-card.simple>
    <div wire:ignore>
        @livewire("modals.create-survey-question", [
            "survey" => $survey
        ])
        @livewire("modals.edit-survey-question")
    </div>
</x-layouts.app>
