<x-layouts.auth>
    <div class="self-center bg-white w-1/5 mx-auto mt-24 rounded-lg shadow p-4">
        <div class="text-center text-xl mb-3">Login</div>
        <form wire:submit.prevent="submitLogin()">
            @if($errors->has('login'))
                @foreach($errors->all() as $error)
                    <x-alert.error>{{ $error }}</x-alert.error>
                @endforeach
            @endif
            <x-div>
                <x-input.simple name="username" placeholder="Username" wire:model="username" />
            </x-div>
            <x-div>
                <x-input.simple type="password" name="password" placeholder="Password" wire:model="password" />
            </x-div>
            <x-div>
                <x-button.primary class="w-full">Submit</x-button.primary>
            </x-div>
        </form>
    </div>
</x-layouts.auth>
