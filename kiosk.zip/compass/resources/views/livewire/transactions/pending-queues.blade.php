<div wire:poll>
    @if($queuedTransactions->isEmpty())
        <div class="mb-5 text-gray-500">NO CUSTOMER AVAILABLE</div>
    @else
        <div class="mb-5 text-gray-500">PENDING QUEUES</div>
        @foreach($queuedTransactions as $transaction)
            <x-card.simple class="mb-3 px-5 py-5 text-gray-800">
                <div class="text-lg font-semibold">{{ $transaction->counter_id }}</div>
                <div>{{ $transaction->payload_data->document_type }}</div>
            </x-card.simple>
        @endforeach
    @endif
</div>
