<div class="self-center text-center" wire:poll.1000ms>
    <div class="text-3xl text-blue-500 mb-2">{{ $waitingTime }}</div>
    <div class="text-lg text-blue-500">Waiting for Customer</div>
</div>
