<div class="px-5 py-8">
    <img src="/images/compass.png" class="h-10 mx-auto" />
</div>
<div class="text-center text-blue-500 text-3xl">Hi there</div>
