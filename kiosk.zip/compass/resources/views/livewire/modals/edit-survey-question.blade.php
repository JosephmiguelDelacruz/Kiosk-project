<div x-data="{open: @entangle('showModal')}">
    <x-modal.simple>
        <x-modal.title>
            Edit Question
        </x-modal.title>
        <div class="px-5 py-4">
            <form wire:submit.prevent>
                <x-div>
                    <x-input.label :required="true">Question</x-input.label>
                    <textarea class="w-full px-3 py-3 border rounded" wire:model="question"></textarea>
                </x-div>
            </form>
        </div>
        <x-modal.footer>
            <x-button.primary wire:click="updateQuestion">Save Changes</x-button.primary>
            <x-button.default x-on:click="open = false">Cancel</x-button.default>
        </x-modal.footer>
    </x-modal.simple>
</div>
