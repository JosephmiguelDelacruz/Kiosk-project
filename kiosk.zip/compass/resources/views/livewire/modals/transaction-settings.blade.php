<div x-data="{open: @entangle('showModal')}">
    <x-modal.simple>
        <x-modal.title>
            Session Settings
        </x-modal.title>
        <div class="px-5 py-4">
            <form wire:submit.prevent>
                <x-div>
                    <x-input.label :required="true">Name</x-input.label>
                    <x-input.simple placeholder="e.g. Window 1" name="session_name" wire:model="session_name" />
                </x-div>
                <div class="text-gray-500">
                    <input type="checkbox" id="auto_accept" name="auto_accept" wire:model="auto_accept"/> <label class="select-none cursor-pointer" for="auto_accept">Auto accept next queue</label>
                </div>
            </form>
        </div>
        <x-modal.footer>
            <x-button.primary wire:click="updateSettings">Save Changes</x-button.primary>
            <x-button.default x-on:click="open = false">Cancel</x-button.default>
        </x-modal.footer>
    </x-modal.simple>
</div>
