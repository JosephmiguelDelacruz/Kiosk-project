<div x-data="{open: @entangle('showModal')}">
    <x-modal.simple>
        <x-modal.title>
            Cancel Transaction
        </x-modal.title>
        <div class="px-5 py-4">
            <form wire:submit.prevent>
                <x-div>
                    <x-input.label :required="true">Reason</x-input.label>
                    <x-input.simple name="reason" placeholder="Enter reason." wire:model="reason" />
                </x-div>
            </form>
        </div>
        <x-modal.footer>
            <x-button.primary wire:click="cancelTransaction">Continue</x-button.primary>
            <x-button.default x-on:click="open = false">Cancel</x-button.default>
        </x-modal.footer>
    </x-modal.simple>
</div>
