<x-layouts.app>
    @foreach($surveys as $survey)
        <x-card.simple class="mb-3 py-3 px-3">
                <div class="text-3xl mb-1 font-semibold text-blue-500">{{ $survey->name }}</div>
                <div class="text-sm mb-5">{{ $survey->questions->count() }} questions available</div>
                <div>
                    <x-button.primary route="{{ route('survey-manage-questions', $survey) }}">
                        <x-heroicon-s-pencil-square class="w-5 h-5 inline-block" />
                        Manage Questions</x-button.primary>
                </div>
        </x-card.simple>
    @endforeach
</x-layouts.app>
