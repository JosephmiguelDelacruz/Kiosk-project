<div>
    <div class="px-5 py-8">
        <img src="/images/compass.png" class="h-10 mx-auto" />
    </div>
    <div class="my-4 text-center mb-5" wire:poll>
        <div class="text-6xl font-semibold text-blue-600 mb-2">{{ now()->format('h:i A') }}</div>
        <div class="text-xl text-blue-500">{{ today()->format('d M, Y') }}</div>
    </div>
    <div class="flex mx-10 gap-10 justify-between">
        <div class="flex flex-col gap-5 w-1/3">
            <a href="{{ route('document-request', $kiosk) }}" class="bg-blue-500 px-5 py-8 rounded-lg text-white text-center hover:bg-blue-600">
                <div class="mb-5">
                    <x-heroicon-s-document-text class="w-14 h-14 mx-auto mb" />
                </div>
                <div class="text-2xl">
                    Document Request
                </div>
            </a>
            <div class="bg-blue-500 px-5 py-8 rounded-lg text-white text-center">
                <div class="mb-5">
                    <x-heroicon-s-building-library class="w-14 h-14 mx-auto mb" />
                </div>
                <div class="text-2xl">
                    School Directory
                </div>
            </div>
            <a href="{{ route('customer-survey', $kiosk) }}" class="bg-blue-500 px-5 py-8 rounded-lg text-white text-center hover:bg-blue-600">
                <div class="mb-5">
                    <x-heroicon-s-pencil-square class="w-14 h-14 mx-auto mb" />
                </div>
                <div class="text-2xl">
                    Customer Satisfaction Survey
                </div>
            </a>
        </div>
        <div class="w-2/3">
            <img src="/images/ready-back-school.jpg" class="w-full h-[70vh]" />
        </div>
    </div>

</div>
