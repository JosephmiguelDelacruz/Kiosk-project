<div class="p-10 bg-blue-500 absolute left-0 top-0 w-full h-full">
    @livewire("kiosk.monitoring.now-serving")

    @livewire("kiosk.monitoring.waiting-list")
</div>
