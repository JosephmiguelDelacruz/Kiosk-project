<div class="p-10">
    <div class="flex gap-5 mb-5">
        <a href="{{ route('document-request-selected', [$kiosk, 'tor']) }}" class="bg-white shadow p-6 rounded-xl">
            <x-heroicon-o-arrow-left class="w-10 h-10 text-blue-500" />
        </a>
        <div class="bg-blue-500 shadow p-6 rounded-xl text-3xl flex-grow text-center text-white flex justify-center gap-x-3">
            <x-heroicon-s-document-text class="w-10 h-10" />

            <div class="self-center">Document Request</div>
        </div>
        <a href="{{ route('kiosk', $kiosk) }}" class="bg-white shadow p-6  rounded-xl">
            <x-heroicon-o-home class="w-10 h-10 text-blue-500" />
        </a>
    </div>
    <div class="text-center mb-10 mt-10`">
        <div class="text-xl mb-10 text-gray-500 py-8">
            Thank you for using the queue system. <br /> Please get your number and wait for your turn.
        </div>
        <div class="text-6xl text-blue-500">{{ $transaction->counter_id }}</div>
    </div>
    <div class="grid grid-cols-3 justify-center mb-5">
        <div></div>
        <div class="border rounded bg-white px-6 py-8 w-full">
            <div class="text-xl text-center mb-5">Transaction details</div>
            <div>Type: Document Request</div>
            <div>Name: {{ $payload['document_type'] }}</div>
            <div>Student Number: {{ $transaction->student_number ?? "Not Indicated" }}</div>
        </div>
    </div>
    <div class="text-center">
        <x-button.primary wire:click="printQueueNumber">Print Number</x-button.primary>
    </div>
</div>
