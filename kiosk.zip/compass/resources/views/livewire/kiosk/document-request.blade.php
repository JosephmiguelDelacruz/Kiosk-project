<div class="p-10">
    <div class="flex gap-5 mb-5">
        <a href="{{ route('kiosk', $kiosk) }}" class="bg-white shadow p-6 rounded-xl">
            <x-heroicon-o-arrow-left class="w-10 h-10 text-blue-500" />
        </a>
        <div class="bg-blue-500 shadow p-6 rounded-xl text-3xl flex-grow text-center text-white flex justify-center gap-x-3">
            <x-heroicon-s-document-text class="w-10 h-10" />

            <div class="self-center">Document Request</div>
        </div>
        <a href="{{ route('kiosk', $kiosk) }}" class="bg-white shadow p-6  rounded-xl">
            <x-heroicon-o-home class="w-10 h-10 text-blue-500" />
        </a>
    </div>
    <div class="p-5 text-center text-xl mb-5">
        Select type of Document
    </div>
    <div class="grid grid-cols-3 gap-10">
        <a href="{{ route('document-request-selected', [$kiosk, 'tor']) }}" class="bg-blue-500 text-white p-5 rounded-xl">
            <div class="text-xl text-center">Transcript of Records</div>
        </a>
        <a href="{{ route('document-request-selected', [$kiosk, 'others']) }}" class="bg-blue-500 text-white p-5 rounded-xl">
            <div class="text-xl text-center">Others</div>
        </a>
    </div>
</div>
