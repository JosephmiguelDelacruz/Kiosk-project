<div class="flex flex-col w-full h-full absolute top-0 left-0">
    <div class="bg-blue-500 text-white px-5 py-4 text-3xl">Customer Satisfaction Survey</div>
    <div class="flex-grow w-full h-full flex justify-center mb-20" >
        <div class="self-center w-2/3">
            <div class="text-3xl mb-10 font-semibold text-gray-500">
                {{ $currentNumber + 1 }}. {{ $currentQuestion->question }}
            </div>
            <div class="text-center text-gray-500 mb-5">Choose a number from 1 to 5. (The number 5 is the highest)</div>
            <div class="grid grid-cols-5 w-full text-gray-500 mb-10">
                @for($i = 0; $i < 5; $i++)
                    <div class="text-4xl border px-5 py-10 text-center font-semibold cursor-pointer {{ $selectedIndex === $i ? 'bg-blue-500 text-white' : '' }}" wire:click="selectAnswer({{ $i }})">
                    {{ $i + 1 }}</div>
                @endfor
            </div>
            @if($loading)
            <div class="px-5 py-3 text-white bg-indigo-500 text-center rounded">Loading next question ...</div>
            @endif
            @if($submitting)
            <div class="px-5 py-3 text-white bg-green-500 text-center rounded">Submitting answers ...</div>
            @endif
        </div>
    </div>
</div>

@push('scripts')
    <script>
        document.addEventListener('selectedAnswer', () => {
            setTimeout(() => {
                Livewire.emit('showQuestion');
            }, 1000)
        })
    </script>
@endpush
