<div wire:poll>
    @if(!$windows->isEmpty())
        <div class="text-3xl mb-5 text-white">Now Serving</div>
        <div class="grid grid-cols-4 mb-10 gap-10">
            @foreach($windows as $window)
                <div>
                    <x-card.simple class="bg-blue-800 px-5">
                        <div class="text-center text-white py-5">
                            <div class="text-xl px-5 mb-5 text-center uppercase">{{ $window->name }}</div>
                            <div class="bg-blue-700 py-5">
                                <div class="text-6xl font-semibold">{{ $window->activeTransaction->counter_id ?? '-' }}</div>
                            </div>
                        </div>
                    </x-card.simple>
                </div>
            @endforeach
        </div>
    @else
        <div class="text-white text-xl mb-10">No active counters available.</div>
    @endif
</div>
