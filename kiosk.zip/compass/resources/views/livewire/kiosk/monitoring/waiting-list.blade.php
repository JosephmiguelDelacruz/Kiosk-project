<div wire:poll>
    @if(!$waitingList->isEmpty())
        <div>
            <div class="text-3xl mb-5 text-white">Waiting List</div>
            <div class="grid grid-cols-4 gap-10">
                @foreach($waitingList as $waiting)
                    <x-card.simple class="bg-blue-800 text-white">
                        <div class="text-4xl p-5 text-center">{{ $waiting->counter_id }}</div>
                    </x-card.simple>
                @endforeach
            </div>
        </div>
    @endif
</div>
