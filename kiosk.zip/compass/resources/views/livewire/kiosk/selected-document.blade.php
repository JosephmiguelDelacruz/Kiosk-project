<div class="p-10">
    <div class="flex gap-5 mb-5">
        <a href="{{ route('document-request', $kiosk) }}" class="bg-white shadow p-6 rounded-xl">
            <x-heroicon-o-arrow-left class="w-10 h-10 text-blue-500" />
        </a>
        <div class="bg-blue-500 shadow p-6 rounded-xl text-3xl flex-grow text-center text-white flex justify-center gap-x-3">
            <x-heroicon-s-document-text class="w-10 h-10" />

            <div class="self-center">Document Request</div>
        </div>
        <a href="{{ route('kiosk', $kiosk) }}" class="bg-white shadow p-6  rounded-xl">
            <x-heroicon-o-home class="w-10 h-10 text-blue-500" />
        </a>
    </div>
    <div class="p-5 text-center text-4xl mb-5 text-blue-500">
        {{ $document }}
    </div>
    <div class="w-2/5 mx-auto mb-10">
        <x-input.simple placeholder="Enter Student Number (optional)" class="text-2xl py-5 px-8 input" id="inputNumber" wire:model="studentNumber"/>
    </div>
    <div class="text-center" wire:ignore>
        <x-button.primary class="py-5 px-10 text-3xl rounded-lg" wire:click="submitTransaction">
            Continue
            <x-heroicon-s-arrow-right class="w-8 h-8 inline-block" />
        </x-button.primary>
    </div>
    <div class="absolute w-full bottom-0 left-0" style="display: none" id="keyboard_wrapper" wire:ignore>
        <div class="w-1/2 mx-auto">
            <div class="simple-keyboard"></div>
        </div>
    </div>
</div>

@push('scripts')
    @vite('resources/js/keyboard.js')

    <script>
        function setInputNumber(value) {
            @this.set('studentNumber', value);
        }
    </script>
@endpush

@push('styles')
    <style>
        .hg-button {
            height: 60px !important;
        }
    </style>
@endpush
