<x-layouts.app>
    <div class="flex h-full absolute w-full flex-col z-10" wire:poll>
        @empty($transactionSession)
            <x-card.simple class="self-center w-1/5 p-4">
                <div class="text-xl text-center mb-3">Begin Session</div>
                <form wire:submit.prevent="createSession">
                    <x-div>
                        <x-input.label :required="true">Name</x-input.label>
                        <x-input.simple placeholder="e.g. Window 1" wire:model="session_name" />
                    </x-div>
                    <x-button.primary class="w-full">Submit</x-button.primary>
                </form>
            </x-card.simple>
        @else
            <div class="mb-4 flex justify-between">
                <div class="py-5">
                    <div class="text-gray-500">Session Number: {{ sprintf("%08d", $transactionSession->id) }}</div>
                    <div class="text-4xl font-semibold text-gray-700"> {{ $transactionSession->name }}</div>
                </div>
                <div class="self-center" wire:click="$emit('showTransactionSettings')">
                    <x-button.primary>
                        <x-heroicon-s-cog-6-tooth class="w-5 h-5 inline-block" />
                        Settings</x-button.primary>
                </div>
            </div>
            @livewire('modals.transaction-settings', [
                "session" => $transactionSession
            ])

            @empty($transactionSession->started_at)
                <div>
                    <x-button.primary wire:click="acceptCustomers"> <x-heroicon-s-play class="w-5 h-5 mb-1 inline-block" /> Start accepting customers</x-button.primary>
                </div>
            @else

                <div class="grid grid-cols-3 gap-10">
                    <div class="col-span-2">
                        @if($activeTransaction)
                            @php
                                $forProcessing = $activeTransaction
                            @endphp
                            <div x-data="{accepting: false, completing: false, cancelling: false}">
                                <x-card.simple class="px-8 py-8 mb-5">
                                    <div class="relative">
                                        @if($activeTransaction->status == "accepted")
                                            <div class="bg-gray-100 bg-opacity-50 absolute top-0 left-0 h-full w-full flex justify-center">
                                                @livewire("transactions.waiting-time", [
                                                    "transaction" => $activeTransaction
                                                ])
                                            </div>
                                        @endif
                                        <div class="uppercase text-blue-400">Queue Number</div>
                                        <div class="text-5xl text-blue-500 font-semibold mb-10">D-001</div>
                                        <div class="mb-10">
                                            <div>Type: Document Request</div>
                                            <div>Document: Transcript of Records</div>
                                            <div>Student Number: Not indicated</div>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-5">
                                        @if($activeTransaction->status == "in progress")
                                            <button wire:click="setComplete" x-bind:disabled="completing" x-on:click="completing = true" class="bg-green-500 text-white text-2xl text-center py-8 cursor-pointer hover:bg-green-600 disabled:opacity-50">
                                                <x-heroicon-s-check class="w-8 h-8 inline-block" />
                                                Mark as Complete
                                            </button>
                                        @endif
                                        @if($activeTransaction->status == "accepted")
                                            <button x-bind:disabled="accepting" x-on:click="accepting = true" wire:click="beginTransaction" class="bg-blue-500 text-white text-2xl text-center py-8 cursor-pointer hover:bg-blue-600 disabled:opacity-50">
                                                <x-heroicon-s-play class="w-8 h-8 inline-block" />
                                                Begin Transaction
                                            </button>
                                        @endif
                                        <button wire:click="$emit('showCancelTransaction')" x-bind:disabled="cancelling" class="bg-red-500 text-white text-2xl text-center py-8 cursor-pointer hover:bg-red-600">
                                            <x-heroicon-s-x-mark class="w-8 h-8 inline-block" />
                                            Mark as Cancelled
                                        </button>
                                    </div>
                                </x-card.simple>
                            </div>

                            @if ($activeTransaction->status == "accepted" || $activeTransaction->status == "in progress")
                                @livewire('modals.cancel-transaction')
                            @endif
                        @else
                            @if ($queuedTransactions->isEmpty())
                                No customers as of the moment.
                            @else
                                <x-button.primary wire:click="acceptAvailableQueue">
                                    <x-heroicon-s-play class="w-5 h-5 mb-1 inline-block" /> Accept available queue</x-button.primary>
                            @endif
                        @endif
                    </div>

                    @livewire("transactions.pending-queues")
                </div>
            @endempty
        @endempty
    </div>


</x-layouts.app>
