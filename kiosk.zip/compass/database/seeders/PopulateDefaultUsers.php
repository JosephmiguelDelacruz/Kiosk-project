<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class PopulateDefaultUsers extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                "name" => "Admin",
                "username" => "admin",
                "email" => "admin@compass.com",
                "password" => Hash::make("admin1234"),
                "role" => "admin"
            ],
            [
                "name" => "Staff One",
                "username" => "staff1",
                "email" => "staff1@compass.com",
                "password" => Hash::make("123456"),
                "role" => "staff"
            ],
        ];

        $persistedUsers = User::all()->keyBy("username");

        foreach ($users as $record) {
            $key = $record["username"];
            $role = $record["role"];

            unset($record["role"]);
            $user = $persistedUsers[$key] ?? new User;
            $user->fill($record);
            $user->save();

            if (!$user->hasRole($role)) {
                $user->assignRole($role);
            }
        }
    }
}
