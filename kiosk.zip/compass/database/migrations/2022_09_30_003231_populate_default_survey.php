<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $survey = \App\Models\Survey::firstOrCreate([
            "name" => "Customer Satisfaction Survey",
            "published" => true
        ]);

        $questions = [
            "Survey Question 1",
            "Survey Question 2",
            "Survey Question 3",
            "Survey Question 4",
        ];

        $persistedQuestions = $survey->questions->keyBy("question");
        foreach ($questions as $question) {
            $surveyQuestion = $persistedQuestions[$question] ?? new \App\Models\SurveyQuestion;
            $surveyQuestion->survey()->associate($survey);
            $surveyQuestion->question = $question;
            $surveyQuestion->save();
        }

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
};
