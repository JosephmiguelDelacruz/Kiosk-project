<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->string("type");
            $table->text("payload");
            $table->string("status")->comment(implode(",", [
                "pending",
                "accepted",
                "in progress",
                "finished",
                "cancelled",
                "accepted but cancelled",
            ]));
            $table->timestamp("accepted_at")->nullable();
            $table->unsignedBigInteger("accepted_by")->nullable();
            $table->timestamp("completed_at")->nullable();
            $table->unsignedBigInteger("completed_by")->nullable();
            $table->timestamp("cancelled_at")->nullable();
            $table->unsignedBigInteger("cancelled_by")->nullable();
            $table->string("cancelled_reason")->nullable();
            $table->text("report_data")->nullable();
            $table->string("student_number")->nullable();
            $table->string("reference_number")->nullable();
            $table->timestamps();

            $table->foreign("accepted_by")->references("id")->on("users")->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreign("completed_by")->references("id")->on("users")->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreign("cancelled_by")->references("id")->on("users")->cascadeOnDelete()->cascadeOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
};
