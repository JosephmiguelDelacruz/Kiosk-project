<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $roles = [
            "admin",
            "staff"
        ];

        foreach ($roles as $role)
        {
            \Spatie\Permission\Models\Role::create(["name" => $role]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        DB::table("roles")->truncate();
        Schema::enableForeignKeyConstraints();
    }
};
