<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('', \App\Http\Livewire\Home::class)->name('home');
Route::get('login', \App\Http\Livewire\Login::class)->name('login');
Route::group(["prefix" => "kiosk"], function () {
    Route::get('{kiosk}', \App\Http\Livewire\Kiosk::class)->name('kiosk');
    Route::get('{kiosk}/document-request', \App\Http\Livewire\Kiosk\DocumentRequest::class)->name('document-request');
    Route::get('{kiosk}/document-request/new/{type}', \App\Http\Livewire\Kiosk\SelectedDocument::class)->name('document-request-selected');
    Route::get('{kiosk}/document-request/complete/{transaction}', \App\Http\Livewire\Kiosk\CompleteDocument::class)->name('document-request-completed');
    Route::get('{kiosk}/customer-survey', \App\Http\Livewire\Kiosk\CustomerSurvey::class)->name('customer-survey');
});

Route::get('monitoring', \App\Http\Livewire\Kiosk\Monitoring::class)->name('kiosk-monitoring');

Route::group(['middleware' => 'auth'], function () {
    Route::get('dashboard', \App\Http\Livewire\Dashboard::class)->name('dashboard');
    Route::get('logout', function () {
        auth()->logout();
        return redirect("/");
    })->name("logout");

    Route::get('transactions', \App\Http\Livewire\Transactions::class)->name('transactions');
    Route::get('survey', \App\Http\Livewire\Survey::class)->name('survey');
    Route::get('survey/{survey}/manage-questions', \App\Http\Livewire\Survey\ManageQuestions::class)->name('survey-manage-questions');

    Route::post("kiosk/print-number/{transaction}", \App\Http\Livewire\Kiosk\PrintNumber::class)->name('kiosk-print-number');
});

