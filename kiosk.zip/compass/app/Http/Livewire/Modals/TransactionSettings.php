<?php

namespace App\Http\Livewire\Modals;

use App\Models\TransactionSession;
use Livewire\Component;

class TransactionSettings extends Component
{
    public bool $showModal = false;
    public string $session_name = "";
    public bool $auto_accept = false;
    public TransactionSession $session;

    public function mount(TransactionSession $session)
    {
        $this->session = $session;
    }

    protected $listeners = [
        'showTransactionSettings'
    ];

    public function render()
    {
        return view('livewire.modals.transaction-settings');
    }

    public function updateSettings()
    {
        $this->validate([
            "session_name" => "required",
        ]);

        $this->emit('updateSession', $this->session_name, $this->auto_accept);
        $this->showModal = false;
    }

    public function showTransactionSettings()
    {
        $this->showModal = true;
        $this->session_name = $this->session->name;
        $this->auto_accept = $this->session->auto_accept;
    }
}
