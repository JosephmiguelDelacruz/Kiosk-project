<?php

namespace App\Http\Livewire\Modals;

use App\Models\SurveyQuestion;
use Livewire\Component;

class EditSurveyQuestion extends Component
{
    public bool $showModal = false;
    public SurveyQuestion $surveyQuestion;
    public string $question;

    protected $listeners = [
        'showEditSurveyQuestion'
    ];

    public function render()
    {
        return view('livewire.modals.edit-survey-question');
    }

    public function showEditSurveyQuestion(SurveyQuestion $question)
    {
        $this->surveyQuestion = $question;
        $this->showModal = true;
        $this->question = $question->question;
        $this->resetErrorBag();
    }

    public function updateQuestion()
    {
        $this->validate([
            "question" => "required"
        ]);

        $this->emit('updateSurveyQuestion', $this->surveyQuestion, $this->question);
        $this->showModal = false;
    }
}
