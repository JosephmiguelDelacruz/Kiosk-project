<?php

namespace App\Http\Livewire\Modals;

use App\Http\Repositories\TransactionRepository;
use Livewire\Component;

class CancelTransaction extends Component
{
    public bool $showModal = false;
    public string $reason;

    protected $listeners = [
        'showCancelTransaction'
    ];


    public function render()
    {
        return view('livewire.modals.cancel-transaction');
    }

    public function cancelTransaction()
    {
        $this->validate([
            "reason" => "required"
        ]);

        $this->emit('confirmedCancelTransaction', $this->reason);
        $this->showModal = false;
    }


    public function showCancelTransaction()
    {
        $this->showModal = true;
        $this->reason = "";
        $this->resetErrorBag();

    }
}
