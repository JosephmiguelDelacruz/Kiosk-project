<?php

namespace App\Http\Livewire\Modals;

use App\Models\SurveyQuestion;
use Livewire\Component;
use App\Models\Survey;

class CreateSurveyQuestion extends Component
{
    public bool $showModal = false;
    public Survey $survey;
    public string $question;

    protected $listeners = [
        "showCreateQuestion"
    ];

    public function mount(Survey $survey)
    {
        $this->survey = $survey;
    }

    public function render()
    {
        return view('livewire.modals.create-survey-question');
    }

    public function showCreateQuestion()
    {
        $this->showModal = true;
        $this->question = "";
        $this->resetErrorBag();
    }

    public function saveQuestion()
    {
        $this->validate([
            "question" => "required"
        ]);

        $surveyQuestion = new SurveyQuestion;
        $surveyQuestion->survey()->associate($this->survey);
        $surveyQuestion->question = $this->question;
        $surveyQuestion->save();

        $this->emit('refreshSurveyQuestions');
        $this->showModal =  false;
    }
}
