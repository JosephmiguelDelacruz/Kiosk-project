<?php

namespace App\Http\Livewire\Transactions;

use App\Http\Repositories\TransactionRepository;
use Livewire\Component;

class PendingQueues extends Component
{

    protected $listeners = [
        'reloadPendingQueues' => '$refresh'
    ];

    public function render()
    {
        return view('livewire.transactions.pending-queues', [
            "queuedTransactions" => app(TransactionRepository::class)->pendingTransactions()
        ]);
    }
}
