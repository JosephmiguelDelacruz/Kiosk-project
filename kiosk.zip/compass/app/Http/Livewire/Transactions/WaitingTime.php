<?php

namespace App\Http\Livewire\Transactions;

use App\Models\Transaction;
use Carbon\Carbon;
use Livewire\Component;

class WaitingTime extends Component
{
    public Carbon $acceptedAt;
    public function mount(Transaction $transaction)
    {
        $this->acceptedAt = $transaction->accepted_at;
    }

    public function render()
    {
        $waitingTime = $this->acceptedAt->diffInSeconds(now());
        return view('livewire.transactions.waiting-time', [
            "waitingTime" => gmdate("H:i:s", $waitingTime)
        ]);;
    }
}
