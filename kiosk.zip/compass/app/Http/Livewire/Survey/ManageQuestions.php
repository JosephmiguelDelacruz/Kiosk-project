<?php

namespace App\Http\Livewire\Survey;

use App\Models\SurveyQuestion;
use Livewire\Component;
use App\Models\Survey;
use Illuminate\Support\Collection;

class ManageQuestions extends Component
{
    public Survey $survey;

    protected $listeners = [
        'refreshSurveyQuestions' => '$refresh',
        'updateSurveyQuestion'
    ];

    public function mount(Survey $survey)
    {
        $this->survey = $survey;
    }

    public function render()
    {
        return view('livewire.survey.manage-questions', [
            "survey" => $this->survey,
            "surveyQuestions" => $this->getSurveyQuestions()
        ]);
    }

    private function getSurveyQuestions()
    {
        return SurveyQuestion::where("survey_id", $this->survey->id)->get();
    }

    public function editQuestion(SurveyQuestion $surveyQuestion)
    {
        $this->emit('showEditSurveyQuestion', $surveyQuestion);
    }

    public function updateSurveyQuestion(SurveyQuestion $surveyQuestion, string $question)
    {
        $surveyQuestion->update([
            "question" => $question
        ]);

        $this->emitSelf('refreshSurveyQuestions');
    }
}
