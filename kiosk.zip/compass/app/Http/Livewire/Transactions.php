<?php

namespace App\Http\Livewire;

use App\Http\Repositories\TransactionRepository;
use App\Models\TransactionSession;
use Livewire\Component;
use Illuminate\Support\Collection;
use App\Models\Transaction;

class Transactions extends Component
{
    public string $session_name = "";

    protected $listeners = [
        'refreshPage' => '$refresh',
        'confirmedCancelTransaction' => 'setCancelled',
        'updateSession'
    ];

    public function render()
    {

        return view('livewire.transactions', [
            "transactionSession" => auth()->user()->activeTransactionSession ?? null,
            "queuedTransactions" => app(TransactionRepository::class)->pendingTransactions(),
            "activeTransaction" => auth()->user()->forProcessingTransaction ?? auth()->user()->transactionBeingProcessed ?? null
        ]);
    }

    public function createSession()
    {
        $this->validate([
            "session_name" => "required"
        ]);

        $session = new TransactionSession;
        $session->name = $this->session_name;
        auth()->user()->transactionSessions()->save($session);

        $this->emitSelf('refreshPage');
    }

    public function acceptCustomers()
    {
        auth()->user()->activeTransactionSession->update([
            "started_at" => now()
        ]);

        $this->emitSelf('refreshPage');
        $this->emit('reloadPendingQueues');
    }

    public function acceptAvailableQueue()
    {
        app(TransactionRepository::class)->getAvailableTransaction(null, auth()->user()->activeTransactionSession);
        $this->emitSelf('refreshPage');
        $this->emit('reloadPendingQueues');
    }

    public function beginTransaction()
    {
        $activeTransaction = auth()->user()->forProcessingTransaction;
        if ($activeTransaction) {
            app(TransactionRepository::class)->updateTransaction($activeTransaction, [
                "status" => "in progress",
            ]);
        }

        $this->emitSelf('refreshPage');
    }

    public function setComplete()
    {
        $activeTransaction = auth()->user()->transactionBeingProcessed;
        if ($activeTransaction) {
            app(TransactionRepository::class)->completeTransaction($activeTransaction, []);
        }
        $this->emitSelf('refreshPage');
    }

    public function setCancelled(string $reason)
    {
        $activeTransaction = auth()->user()->forProcessingTransaction ?? auth()->user()->transactionBeingProcessed;
        if ($activeTransaction) {
            app(TransactionRepository::class)->cancelTransaction($activeTransaction, $reason);
        }
        $this->emitSelf('refreshPage');
    }

    public function updateSession(string $sessionName, bool $autoAccept)
    {
        auth()->user()->activeTransactionSession->update([
            "name" => $sessionName,
            "auto_accept" => $autoAccept
        ]);

        $this->emitSelf('refreshPage');
    }
}
