<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Survey extends Component
{
    public function render()
    {
        return view('livewire.survey', [
            "surveys" => \App\Models\Survey::all()
        ]);
    }
}
