<?php

namespace App\Http\Livewire\Kiosk;

use App\Models\Transaction;
use Livewire\Component;

class PrintNumber extends Component
{
    public string $queueNumber;

    public function mount(Transaction $transaction)
    {
        $this->queueNumber = $transaction->counter_id ?? "Test";
    }

    public function render()
    {
        return view('livewire.kiosk.print-number');
    }
}
