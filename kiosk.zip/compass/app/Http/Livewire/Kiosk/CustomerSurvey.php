<?php

namespace App\Http\Livewire\Kiosk;

use App\Models\Survey;
use App\Models\SurveyQuestion;
use Livewire\Component;
use Illuminate\Support\Collection;

class CustomerSurvey extends Component
{
    public int $currentNumber = 0;
    public Collection $questions;
    public SurveyQuestion $currentQuestion;
    public ?int $selectedIndex = null;
    public bool $loading;
    public bool $submitting = false;

    protected $listeners= [
        "showQuestion"
    ];

    public function mount()
    {
        $survey = Survey::with('questions')->first();
        $this->questions = $survey->questions;
        $this->getCurrentQuestion();
    }

    public function render()
    {
        return view('livewire.kiosk.customer-survey');
    }

    private function getCurrentQuestion()
    {
        $this->currentQuestion = $this->questions->get($this->currentNumber);

    }

    public function selectAnswer($index)
    {
        $this->selectedIndex = $index;
        $hasNext = $this->currentNumber + 1 < $this->questions->count();

        if ($hasNext) {
            $this->loading = true;
            $this->dispatchBrowserEvent("selectedAnswer");
        } else {
            $this->submitting = true;

        }

    }

    public function showQuestion()
    {
        $this->loading = false;
        $this->currentNumber++;
        $this->getCurrentQuestion();
        $this->selectedIndex = null;
    }
}
