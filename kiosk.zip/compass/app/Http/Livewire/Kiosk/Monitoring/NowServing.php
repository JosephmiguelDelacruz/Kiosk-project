<?php

namespace App\Http\Livewire\Kiosk\Monitoring;

use App\Models\TransactionSession;
use Illuminate\Support\Collection;
use Livewire\Component;

class NowServing extends Component
{
    public function render()
    {
        return view('livewire.kiosk.monitoring.now-serving', [
            "windows" => TransactionSession::whereDate('created_at', today())->whereNotNull('started_at')->with('activeTransaction')->get()
        ]);
    }
}
