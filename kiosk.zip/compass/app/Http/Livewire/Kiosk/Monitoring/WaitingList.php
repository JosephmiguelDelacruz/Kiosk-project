<?php

namespace App\Http\Livewire\Kiosk\Monitoring;

use App\Http\Repositories\TransactionRepository;
use Illuminate\Support\Collection;
use Livewire\Component;

class WaitingList extends Component
{
    public function render()
    {
        return view('livewire.kiosk.monitoring.waiting-list', [
            'waitingList' => app(TransactionRepository::class)->pendingTransactions()
        ]);
    }
}
