<?php

namespace App\Http\Livewire\Kiosk;

use App\Http\Repositories\TransactionRepository;
use App\Models\TransactionSession;
use Illuminate\Support\Collection;
use Livewire\Component;

class Monitoring extends Component
{
    public function render()
    {
        return view('livewire.kiosk.monitoring');
    }
}
