<?php

namespace App\Http\Livewire\Kiosk;

use App\Models\Kiosk;
use Livewire\Component;

class DocumentRequest extends Component
{
    public Kiosk $kiosk;

    public function render()
    {
        return view('livewire.kiosk.document-request');
    }
}
