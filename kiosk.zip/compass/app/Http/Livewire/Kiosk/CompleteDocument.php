<?php

namespace App\Http\Livewire\Kiosk;

use App\Http\Repositories\TransactionRepository;
use App\Models\Kiosk;
use Livewire\Component;
use App\Models\Transaction;
use Mike42\Escpos\PrintConnectors\FilePrintConnector;
use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\Printer;

class CompleteDocument extends Component
{
    public Transaction $transaction;
    public Kiosk $kiosk;
    public string $document;
    public array $payload;

    public function mount(Kiosk $kiosk, Transaction $transaction) {
        $this->transaction = $transaction;
        $this->payload = json_decode($transaction->payload, true);
    }

    public function render()
    {
        return view('livewire.kiosk.complete-document');
    }

    public function printQueueNumber()
    {

        app(TransactionRepository::class)->printNumber($this->transaction);
//        $connector = new WindowsPrintConnector("POS58 v3");
////        $connector = new NetworkPrintConnector("192.168.1.1", 9100);
//        $printer = new Printer($connector);
//        try {
//            $printer->text("Hello World");
//            $printer->cut();
//        } finally {
//            $printer->close();
//        }


    }
}
