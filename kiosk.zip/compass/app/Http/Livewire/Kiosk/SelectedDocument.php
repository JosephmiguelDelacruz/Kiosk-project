<?php

namespace App\Http\Livewire\Kiosk;

use App\Http\Repositories\TransactionRepository;
use Livewire\Component;
use App\Models\Kiosk;

class SelectedDocument extends Component
{
    public string $type;
    public array $documents = [
        "tor" => "Transcript of Records",
        "others" => "Others"
    ];
    public Kiosk $kiosk;
    public mixed $studentNumber = null;

    public function mount(Kiosk $kiosk, string $type)
    {
        $this->type = $type;
        $this->document = $this->documents[$type];
    }

    public function render()
    {
        return view('livewire.kiosk.selected-document');
    }

    public function submitTransaction()
    {
        $transaction = app(TransactionRepository::class)->createTransaction($this->kiosk, 'document',[ "document_type" => $this->document ], $this->studentNumber);

        $this->redirectRoute('document-request-completed', [$this->kiosk, $transaction->id]);
    }
}
