<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Kiosk extends Component
{

    public \App\Models\Kiosk $kiosk;

    public function render()
    {
        return view('livewire.kiosk');
    }
}
