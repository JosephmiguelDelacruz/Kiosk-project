<?php
namespace App\Http\Repositories;


use App\Models\People;

class PeopleRepository {

    /**
     * Saving person record
     * If student, set the relationship as student
     *
     * @param array $payload
     * @return People
     */
    public function createRecord(array $payload): People
    {
        return People::create([
            "first_name" => $payload['first_name'],
            "last_name" => $payload['last_name'],
            "relationship" => $payload['relationship'],
            "student_number" => $payload['student_number'],
            "contact_number" => $payload["contact_number"] ?? null,
            "email" => $payload["email"] ?? null,
        ]);
    }

    public function updateRecord(People $people, array $payload): bool
    {
        return $people->update($payload);
    }


}
