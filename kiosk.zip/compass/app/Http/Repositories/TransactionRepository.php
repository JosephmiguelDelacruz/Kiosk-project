<?php
namespace App\Http\Repositories;

use App\Jobs\PrintQueueNumber;
use App\Models\Kiosk;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use App\Models\TransactionSession;
class TransactionRepository {

    /**
     * Processing Transaction
     * Step 1: Customer get transaction number (pending)
     * Step 2: Counter will accept transaction (accepted), will call the customer to go to specific counter
     * Step 3: Once the customer is on the counter, Counter will mark the transaction as in progress (in progress).
     *          Counter will ask customer information and possibly save information.
     * Step 3 (cancelled): Once the counter has determined that the customer is no longer around for few minutes, can set as cancelled (cancelled)
     * Step 4 (successful): Once the transaction has been completed, set the transaction as complete (finished). Save any useful information to report_data field
     * Step 4 (accepted but cancelled) - change of mind or incomplete requirements): Set the transaction as cancelled and save reason why (cancelled)
     */


    /** Create Transaction
     * @param string $type
     * @param array $payload
     * @return Transaction
     */
    public function createTransaction(Kiosk $kiosk, string $type, array $payload, string $studentNumber = null): Transaction
    {
        return Transaction::create([
            "kiosk_id" => $kiosk->id,
            "type" => $type,
            "counter_id" => $this->generateCounterCode($type),
            "payload" => json_encode($payload),
            "status" => "pending",
            "student_number" => $studentNumber,
        ]);
    }

    private function generateCounterCode(string $type): string
    {
        $count = Transaction::where("type", $type)->whereDate("created_at", Carbon::today())->count();
        $count = $count + 100;
        $prefixes = [
            "bill"      => "B",
            "document"  => "D",
            "others"    => "0"
        ];

        return $prefixes[$type] . "-" . $count;
    }

    public function acceptTransaction(Transaction $transaction, TransactionSession $transactionSession): bool
    {
        return $transaction->update([
            "status" => "accepted",
            "accepted_by" => auth()->id(),
            "accepted_at" => now(),
            "transaction_session_id" => $transactionSession->id
        ]);
    }

    public function updateTransaction(Transaction $transaction, array $payload): bool
    {
        return $transaction->update($payload);
    }

    public function cancelTransaction(Transaction $transaction, string $reason): bool
    {
        return $transaction->update([
            "status" => "cancelled",
            "cancelled_at" => now(),
            "cancelled_by" => auth()->id(),
            "cancelled_reason" => $reason
        ]);
    }

    public function completeTransaction(Transaction $transaction, array $report, ?string $referenceNumber = null):  bool
    {
        return $transaction->update([
            "status" => "finished",
            "completed_at" => now(),
            "completed_by" => auth()->id(),
            "report_data" => json_encode($report),
            "reference_number" => $referenceNumber
        ]);
    }

    public function pendingTransactions(string $type = null): Collection
    {
        return Transaction::where("status", "pending")
            ->when($type, function ($query, $type) {
                $query->where("type", $type);
            })
            ->whereDate("created_at", today())
            ->get();
    }

    /**
     * Returns accepted transaction by the user that was not yet marked as in progress
     *
     * @param User $user
     * @return Transaction|null
     */
    public function acceptedTransaction(User $user): ?Transaction
    {
        return $user->forProcessingTransaction;
    }

    /**
     * Returns accepted transaction that is being processed right now
     *
     * @param User $user
     * @return Transaction|null
     */
    public function activeTransaction(User $user): ?Transaction
    {
        return $user->transactionBeingProcessed;
    }


    /**
     * Get available transaction
     *
     * @param string|null $type
     * @param TransactionSession $transactionSession
     * @return Transaction|null
     */
    public function getAvailableTransaction(string $type = null, TransactionSession $transactionSession): ?Transaction
    {
        $available =  Transaction::where("status", "pending")
            ->when($type, function ($query, $type) {
                $query->where("type", $type);
            })
            ->whereDate("created_at", today())
            ->first();

        if ($available) {
            $this->acceptTransaction($available, $transactionSession);
        }

        return $available;
    }

    public function printNumber(Transaction $transaction): void {
        PrintQueueNumber::dispatch($transaction)->onQueue("printing");
    }
}
