<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class TransactionSession extends Model
{
    use HasFactory;

    protected $fillable = [
        "user_id",
        "name",
        "auto_accept",
        "filters",
        "started_at"
    ];

    /**
     * Relationship to active transaction
     *
     * @return HasOne
     */
    public function activeTransaction(): HasOne
    {
        return $this->hasOne(Transaction::class)->whereIn("status", ["accepted", "in progress"]);
    }
}
