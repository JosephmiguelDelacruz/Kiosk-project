<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use Carbon\Carbon;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'username',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function acceptedTransactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'accepted_by')->where('status', 'accepted');
    }

    /**
     * Relationship to transaction accepted for processing
     * Step 2
     *
     * @return HasOne
     */
    public function forProcessingTransaction(): HasOne
    {
        return $this->hasOne(Transaction::class, 'accepted_by')
                        ->where('status', 'accepted');
    }

    /**
     * Relationship to transaction being processed
     * Step 3
     *
     * @return HasOne
     */
    public function transactionBeingProcessed(): HasOne
    {
        return $this->hasOne(Transaction::class, 'accepted_by')
                    ->where('status', 'in progress');
    }

    /**
     * Relationship to active transaction session
     *
     * @return HasOne
     */
    public function activeTransactionSession(): HasOne
    {
        return $this->hasOne(TransactionSession::class)->whereDate('created_at', Carbon::today());
    }

    /**
     * Relationship to transaction sessions
     *
     * @return HasMany
     */
    public function transactionSessions(): HasMany
    {
        return $this->hasMany(TransactionSession::class);
    }
}
