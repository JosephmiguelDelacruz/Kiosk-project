<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Transaction extends Model
{
    use HasFactory;

    protected $fillable = [
        "type",
        "counter_id",
        "payload",
        "status",
        "accepted_at",
        "accepted_by",
        "completed_at",
        "completed_by",
        "cancelled_at",
        "cancelled_by",
        "cancelled_reason",
        "report_data",
        "student_number",
        "reference_number",
        "transaction_session_id",
        "kiosk_id"
    ];

    protected $dates = [
        "accepted_at",
        "completed_at",
        "cancelled_at",
    ];

    public function getPayloadDataAttribute()
    {
        return json_decode($this->payload);
    }

    public function kiosk(): BelongsTo
    {
        return $this->belongsTo(Kiosk::class);
    }
}
